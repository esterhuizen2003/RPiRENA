#!/bin/bash

export PATH=/sbin:/bin:/usr/sbin:/usr/bin

modprobe spi_bcm2708 || exit

chmod g+rw /dev/spidev0.?
chgrp rpirena /dev/spidev0.?
for port in 23 24 25; do echo $port > /sys/class/gpio/export; done
echo out > /sys/class/gpio/gpio24/direction
echo 1 > /sys/class/gpio/gpio24/value
chmod g+rw /sys/class/gpio/gpio24/value
chgrp rpirena /sys/class/gpio/gpio24/value
