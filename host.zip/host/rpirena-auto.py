#! /usr/bin/python

import rpirena 
rpirena.defaults()
from time import strftime, gmtime
fn=strftime("%Y-%m-%d_%H:%M:%S.EI", gmtime())
rpirena.stream_file(fn)
