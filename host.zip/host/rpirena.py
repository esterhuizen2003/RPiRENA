#! /usr/bin/python -i

import sys
sys.ps1="RPiRENA> "
sys.ps2="RPiRENA. "

import struct
from time import sleep

import os
import spidev
spidevname = "/dev/spidev0.0"
try:
    spi = os.open(spidevname, os.O_RDWR)
    spidev.set_mode(fd=spi, cpol=0, cpha=1)
except OSError, e:
    sys.stderr.write("%s: %s\n" % (spidevname, repr(e)))

def gpio_read(port):
    f = file("/sys/class/gpio/gpio%d/value" % port)
    r = int(f.readline())
    f.close()
    return r

def gpio_write(port, value):
    f = file("/sys/class/gpio/gpio%d/value" % port, "w")
    f.write("%d\n" % value)
    f.close()

nCONFIG=24
nSTATUS=25
CONF_DONE=23

verbosity=1

def altera_reset(timeout=10):
    if verbosity>=2:
        sys.stderr.write("nCONFIG=%d nSTATUS=%d CONF_DONE=%d\n" 
                         % (gpio_read(nCONFIG), 
                            gpio_read(nSTATUS), 
                            gpio_read(CONF_DONE),
                            ))
    gpio_write(nCONFIG, 0);
    nST = gpio_read(nSTATUS)
    n=0
    while nST and n<timeout:
        n += 1
        nST = gpio_read(nSTATUS)
    if verbosity>=2:
        sys.stderr.write("nCONFIG=%d nSTATUS=%d CONF_DONE=%d\n" 
                         % (gpio_read(nCONFIG), 
                            nST, 
                            gpio_read(CONF_DONE),
                            ))
    gpio_write(nCONFIG, 1);
    if nST:
        raise IOError("nSTATUS does not go low")
    nST = gpio_read(nSTATUS)
    n=0
    while not nST and n<timeout:
        n += 1
        nST = gpio_read(nSTATUS)
    if verbosity>=2:
        sys.stderr.write("nCONFIG=%d nSTATUS=%d CONF_DONE=%d\n" 
                         % (gpio_read(nCONFIG), 
                            nST, 
                            gpio_read(CONF_DONE),
                            ))
    if not nST:
        raise IOError("nSTATUS does not go high")

def altera_from_file(fn='rpirena.rbf', hz=30000000):
    altera_reset()
    spidev.set_mode(cpol=0, cpha=0)
    spidev.set_speed(hz=hz)
    f = open(fn)
    n = 0
    while True:
        b = f.read(1024)
        if not b:
            break
        n += len(b)
        spidev.sync_transfer(cmd=b, flags=spidev.INVERT_BITS_OUT, rsize=0)
        nST = gpio_read(nSTATUS)
        if not nST:
            IOError("nSTATUS went low during config")
        if verbosity >= 2:
            CD = gpio_read(CONF_DONE)
            if verbosity >= 3 or CD:
                sys.stderr.write("Altera config %d bytes, CONF_DONE=%d\n" 
                                 % (n, CD))
    CD = gpio_read(CONF_DONE)
    if not CD:
        IOError("CONF_DONE did not go high after config")
    spidev.set_mode(cpol=0, cpha=1)

def cmdstr(w):
    if w & 0xffff4000:
        return struct.pack(">HH", w&0xffff, w>>16)
    return struct.pack(">H", w)

def sync(w):
    r = spidev.sync_transfer(cmd=cmdstr(w))
    if len(r)==4:
        return struct.unpack(">HH", r)
    return struct.unpack(">H", r)[0]

def reg(a, d=None):
    if d==None:
        c = struct.pack(">3H", a|0x8000, 0x8001, 0);
    else:
        c = struct.pack(">4H", a|0xc000, d, 0x8001, 0);
    return struct.unpack(">H", spidev.sync_transfer(cmd=c, rsize=2))[0]


DREG_ADDR = 0xc020
CORE_ADDR = 0x8040
TRIG_ADDR = 0x8100

def filter(ch, p):
    c = ""
    for i in range(16):
        n = p[(i+4)&15][0] & 0x3fL
        a = p[(i+2)&15][1] & 0x1fff
        b = p[(i+2)&15][2] & 0x1fff
        d = (n<<26)|(b<<13)|a;
        c += struct.pack(">6H", DREG_ADDR+1, d&0xffff, DREG_ADDR+2, d>>16, DREG_ADDR+3, 0x800|(ch*16+i))
    spidev.sync_transfer(cmd=c, rsize=0)

l1_trig = [[0,222222222],[0,222222222],[0,222222222],[0,222222222]]

def trigconf(i, v):
    i *= 2
    c = struct.pack(">6H", TRIG_ADDR|0xc000|i, v&0xffff, TRIG_ADDR|0xc001|i, v>>16, 0x8001, 0)
    spidev.sync_transfer(cmd=c, rsize=0)

def i2f(i):
    if i<0:
        s = 0x20000
        i = -i
    else:
        s = 0
        
    if i<0x4000:
        return s|i
    e=1
    while i>=0x4000:
        i>>=1
        e+=1
        if e>15:
            return s|0x1ffff
    return s|(e<<13)|(i&0x1fff)

def f2i(f):
    e = (f>>13)&15
    if e<2:
        m = f & 0x3fff
    else:
        m = (0x2000|f&0x1fff)<<(e-1)
    return -m if f&0x20000 else m

def thres(ch, thr=None, flags=None):
    if flags==None:
        flags = l1_trig[ch][0]
    else:
        l1_trig[ch][0] = flags
    if thr==None:
        thr = l1_trig[ch][1]
    else:
        l1_trig[ch][1] = thr
    trigconf(ch, (flags<<18)|i2f(int(thr)))

def l2trig(i, all=0, none=0, any=0, mask=0xffffffff):
    trigconf(2*i+4, (all<<20)|(none<<10)|any)
    trigconf(2*i+5, mask)

def adcmask(m=0xf):
    return reg(CORE_ADDR, m)
def age(agemin=4, agetrig=12, agemax=15):
    return reg(CORE_ADDR+2, (agemin<<8)|(agetrig<<4)|agemax)
def nsamples(n=0, t=0xff):
    return reg(CORE_ADDR+3, (t<<8)|n)

p22=[
    (30,  1264, -3708),
    ( 1,  1713, -3708),
    ( 5,  3369,     0),
    ( 6,  3642,     0),
    ( 7,  3798,     0),
    ( 8,  3798,     0),
    ( 9,  3583,     0),
    (10,  3096,     0),
    (12,   992,  3321),
    (13,  -685,  4095),
    (17, -4095,     0),
    (18, -4095,     0),
    (19, -4095,     0),
    (20, -4095,     0),
    (21, -4095,     0),
    (22, -4095,     0),
    ]
p1=[
    (20,   -670,   -851),
    ( 1,   -303,  -1070),
    ( 2,    158,  -1153),
    ( 3,    656,  -1263),
    ( 4,   1200,  -1208),
    ( 5,   1721,   -987),
    ( 6,   2147,   -411),
    ( 7,   2325,    339),
    ( 8,   2123,   1337),
    ( 9,   1330,   2454),
    (10,   -128,   2813),
    (12,  -2114,      0),
    (13,  -2114,      0),
    (14,  -2114,      0),
    (15,  -2114,      0),
    (16,  -2103,      0),
    ]

def defaults():
    global mV
    mV=14000.0
    altera_from_file()
    adcmask()
    age()
    nsamples(1)
    for ch in range(4):
        filter(ch, p22)
    thres(0, thr=20*mV, flags=0b0001110100)
    thres(1, thr=20*mV, flags=0b0110011000)
    thres(2, thr=20*mV, flags=0b1010100001)
    thres(3, thr=20*mV, flags=0b1101000010)
    l2trig(0,  any=0b0000000001, mask=0xf)
    l2trig(1,  any=0b0000000010, mask=0xf)
    l2trig(2,  all=0b1000000000, mask=0xf)
    l2trig(3,  any=0b0000001000, mask=0xf)
    l2trig(4,  all=0b0000010000, mask=0xf)
    l2trig(5,  all=0b0001000000, mask=0xf)
    l2trig(6,  all=0b0010000000, mask=0xf)
    l2trig(7,  any=0b0000000100, mask=0xf)

def readrecordcmd(a, n, w=0):
    return struct.pack(">%dH"%(n+2+w), *( (a,)+(0,)*w+(0x8001,)*n+(0,) ))

def readrecord(a, n, w=0):
    c = readrecordcmd(a, n, w)
    return struct.unpack(">%dH"%n, spidev.sync_transfer(cmd=c, rsize=2*n))

def HK():
    return [i & 0xfff for i in readrecord(0x8030, 8)]

def peek(i=0):
    return readrecord(CORE_ADDR+8+i, 4, w=2)
def readcounter(i=1):
    return readrecord(CORE_ADDR+12+i, 4, w=1)
def readtrig():
    w = readrecord(CORE_ADDR+4, 40)
    ww = [(w[i+1]<<16) | w[i] for i in range(0,40,2)]
    l1 = [(i>>18,f2i(i&0x3ffff)) for i in ww[0:4]]
    l2 = [(ww[i+1], ww[i]>>20, (ww[i]>>10)&0x3ff, ww[i]&0x3ff) for i in range(4,20,2)]
    return (l1,l2)

read_event_packet_cmd = readrecordcmd(0x8016, 14)[:-4]+readrecordcmd(0x8012,1)
read_sample_packet_cmd = readrecordcmd(0x8017, 6)[:-4]+readrecordcmd(0x8012,1)

def F2ATB(f):
    A = f2i(f>>14)
    e = (f>>27) & 15
    B = (f>>3) & 0x3fe
    if e>1:
        B <<= e-1
    if f & 0x2000:
        B = -B
    T = f&15
    return (A,T,B)

class histogram(object):
    def __init__(self, fn, mV=14000, b0=-500, n=4000, m=4):
        self.mV=mV
        self.b0=b0
        self.b=[[0]*n for i in range(m)]
        self.fn = fn
        self.fmt = "%d"+" %d"*m+"\n"
    def __iadd__(self, x):
        for i,xx in enumerate(x):
            bb = int(xx/self.mV-self.b0)
            if bb<0:
                bb=0
            if bb>=len(self.b[i]):
                bb = len(self.b[i])-1
            self.b[i][bb] += 1
        return self
    def save(self):
        if not self.fn:
            return
        f = open(self.fn+"+", "w")
        for i in range(len(self.b[0])):
            f.write(self.fmt % ((i+self.b0,)+tuple([b[i] for j,b in enumerate(self.b)])))
        f.close()
        os.rename(self.fn+"+", self.fn)

def stream_events(f, h=None):
    f2s = reg(0x8012)
    while True:
        ne = 0
        while f2s & 0x1000:
            ne += 1
            r = spidev.sync_transfer(cmd=read_event_packet_cmd, rsize=30)
            rr = struct.unpack(">L3H2B9H", r)
            # print >> sys.stderr, "f2stat", hex(f2s), [hex(i) for i in rr]
            if rr[0] != 0xbeefa128L:
                raise IOError("invalid event header")
            f2s = rr[14]
            
            f.write("EI %d 0x%08x 0x%02x %d" % (rr[5], (rr[2]<<16)|rr[1], rr[4], rr[3]))
            j=6
            hh=[]
            for i in (1,2,4,8):
                if rr[1] & i:
                    ATB=F2ATB((rr[j+1]<<16)|rr[j])
                    hh.append(ATB[0])
                    f.write("  %d %d %d" % ATB)
                    j+=2
                else:
                    hh.append(0)
                    f.write("  0 0 0")
            f.write("\n")
            if h:
                h += hh
        s = spidev.sync_transfer(cmd=read_sample_packet_cmd, rsize=14)
        ss = struct.unpack(">4HLH", s)
        f2s = ss[5]
        ns = 0
        while ss[0] == 0x5a61:
            ns += 1
            f.write("S %d %d %d %d %d\n" % (
                    ss[4], 
                    ss[1]>>4, 
                    ((ss[1]&15)<<8)|(ss[2]>>8),
                    ((ss[2]&255)<<4)|(ss[3]>>12),
                    ss[3]&0xfff))
            if f2s & 0x1000:
                break
            s = spidev.sync_transfer(cmd=read_sample_packet_cmd, rsize=14)
            ss = struct.unpack(">4HLH", s)
            f2s = ss[5]
        if not (f2s & 0x1000):
            if ne:
                sleep(0.001)
                if h:
                    h.save()
            else:
                f.flush()
                sleep(0.1)
        f2s = reg(0x8012)

def stream_file(fn):
    f = open(fn, "a")
    h = histogram(fn+"H")
    reg(7, 0x1f0)
    reg(10, 9)
    while True:
        try:
            stream_events(f, h)
        except IOError, e:
            sys.stderr.write(repr(e)+"\n")
            reg(7, 0x1f0)
        except KeyboardInterrupt:
            f.close()
            break

