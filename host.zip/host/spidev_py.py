#! /usr/bin/python
from distutils.core import setup, Extension

m_spidev = Extension('spidev',
                      sources = ['spidev_py.c'],
                      extra_compile_args=['-std=c99'],
                      )

setup (name = 'spidev',
       version = '1.0',
       description = 'spidev transfers',
       ext_modules = [m_spidev],
       )
