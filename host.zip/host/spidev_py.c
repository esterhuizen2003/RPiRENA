
#include "Python.h"
#include <linux/spi/spidev.h>
#include <sys/ioctl.h>
#include <stdio.h>

static struct ssp_job {
	int fd;
	unsigned int idle;
	int count;
	unsigned char *command;
	unsigned int flags;
	unsigned char *buf_start;
	unsigned char *buf_ptr;
	int buf_count;
} job = {
	.fd = -1
};

#define FRAME_BYTE         0x00000000
#define FRAME_WORD         0x00000010
#define FRAME_LONG         0x00000020
#define STREAM_COMPRESS    0x00000400
#define STREAM_DROP_ZEROS  0x00000800
#define INVERT_BITS_OUT    0x00001000

static int set_job_fd(struct ssp_job *j, int fd)
{
	if (fd >= 0)
		j->fd = fd;
	else if (j->fd < 0) {
		PyErr_SetString(PyExc_ValueError, "No file descriptor");
		return -1;
	}
	return 0;
}


static unsigned char buf[4096];
#define MAX_TRANSFER sizeof(buf)

static struct spi_ioc_transfer transfer;
static inline void init_transfer(int n)
{
	transfer.tx_buf = (__u64) buf;
	transfer.rx_buf = (__u64) buf;
	transfer.len = n;
}

static inline __u32 bit_reverse(__u32 i)
{
	return (i>>7) & 0x01010101
	     | (i>>5) & 0x02020202
	     | (i>>3) & 0x04040404
	     | (i>>1) & 0x08080808
	     | (i<<1) & 0x10101010
	     | (i<<3) & 0x20202020
	     | (i<<5) & 0x40404040
	     | (i<<7) & 0x80808080
	     ;
}
static inline void bit_reverse_copy(void *d, void *s, int n)
{
	n = (n+3)>>2;
	__u32 *dd=d, *ss=s;
	while (n--)
		*(dd++) = bit_reverse(*(ss++));
}

static int do_spi_transfer(struct ssp_job *j)
{
	unsigned int n = 0;
	if (j->count && (!j->idle || j->count <= j->buf_count)) {
		if (j->count > MAX_TRANSFER)
			n = MAX_TRANSFER;
		else
			n = j->count;
		if (j->flags & INVERT_BITS_OUT)
			bit_reverse_copy(buf, j->command, n);
		else
			memcpy(buf, j->command, n);
		j->count -= n;
		j->command += n;
	}
	if (j->idle) {
		if (j->flags & FRAME_LONG) 
			while (n < MAX_TRANSFER && n < j->buf_count) {
				*(__u32 *)(buf+n) = j->idle;
				n+=4;
			}
		else if (j->flags & FRAME_WORD) 
			while (n < MAX_TRANSFER && n < j->buf_count) {
				*(__u16 *)(buf+n) = j->idle;
				n+=2;
			}
		else 
			while (n < MAX_TRANSFER && n < j->buf_count)
				buf[n++] = j->idle;
	}
	init_transfer(n);
	if (ioctl(j->fd, SPI_IOC_MESSAGE(1), &transfer)<0) 
		return -1;
	if (j->buf_ptr && j->buf_count) {
		if (n > j->buf_count) {
			memcpy(j->buf_ptr, buf + n - j->buf_count, j->buf_count);
			j->buf_ptr += j->buf_count;
			j->buf_count = 0;
		}
		else {
			memcpy(j->buf_ptr, buf, n);
			j->buf_ptr += n;
			j->buf_count -= n;
		}
	}

	return 0;
}

static PyObject *set_mode(PyObject *self, PyObject *args, PyObject *kw)
{
	static char *arg_names[] = {"mode", "cpha", "cpol", "fd", NULL};
	int mode = 0, cpha = 0, cpol = 0, fd = -1;
	if (!PyArg_ParseTupleAndKeywords(args, kw, 
					 "|iiii", arg_names,
					 &mode, &cpha, &cpol, &fd))
		return NULL;
	if (set_job_fd(&job, fd))
		return NULL;
	if (cpha)
		mode |= SPI_CPHA;
	if (cpol)
		mode |= SPI_CPOL;

	__u8 val = mode & (SPI_CPHA|SPI_CPOL);
	if (ioctl(job.fd, SPI_IOC_WR_MODE, &val) < 0) {
		PyErr_SetFromErrno(PyExc_IOError);
		return NULL;
	}
	Py_RETURN_NONE;
}

static PyObject *set_lsb_first(PyObject *self, PyObject *args, PyObject *kw)
{
	static char *arg_names[] = {"mode", "fd", NULL};
	int mode = 0, fd = -1;
	if (!PyArg_ParseTupleAndKeywords(args, kw, "|ii", arg_names, &mode, &fd))
		return NULL;
	if (set_job_fd(&job, fd))
		return NULL;
	__u8 val = !! mode;
	if (ioctl(job.fd, SPI_IOC_WR_LSB_FIRST, &val) < 0) {
		PyErr_SetFromErrno(PyExc_IOError);
		return NULL;
	}
	Py_RETURN_NONE;
}

static PyObject *set_speed(PyObject *self, PyObject *args, PyObject *kw)
{
	static char *arg_names[] = {"hz", "fd", NULL};
	int hz = 0, fd = -1;
	if (!PyArg_ParseTupleAndKeywords(args, kw, "|ii", arg_names, &hz, &fd))
		return NULL;
	if (set_job_fd(&job, fd))
		return NULL;
	if (ioctl(job.fd, SPI_IOC_WR_MAX_SPEED_HZ, &hz) < 0) {
		PyErr_SetFromErrno(PyExc_IOError);
		return NULL;
	}
	Py_RETURN_NONE;
}

static PyObject *sync_transfer(PyObject *self, PyObject *args, PyObject *kw)
{
	PyObject *r = NULL;
	static char *arg_names[] = {"cmd", "csize", "rsize", "flags", "fd", NULL};
	PyObject *cmd;
	int csize = 0, rsize=MAX_TRANSFER, fd=-1, flags=0;
	if (!PyArg_ParseTupleAndKeywords(args, kw, 
					 "O|iiii", arg_names,
					 &cmd, &csize, &rsize, &flags, &fd))
		return NULL;
	if (set_job_fd(&job, fd))
		return NULL;
	if (rsize>MAX_TRANSFER) {
		PyErr_SetString(PyExc_ValueError, "resp request to large");
		return NULL;
	}
	PyObject *mview = PyMemoryView_FromObject(cmd);
	if (!mview) 
		return NULL;
	Py_buffer *buffer = PyMemoryView_GET_BUFFER(mview);
	if (!buffer)
		goto r_view;
	if (csize && csize > buffer->len) {
		PyErr_SetString(PyExc_ValueError, "cmd too short");
		goto r_buf;
	}
	if (!csize)
		csize = buffer->len;
	job.command = buffer->buf;
	job.idle = 0;
	job.flags = flags;
	job.buf_count = 0;
	job.buf_ptr = NULL;
	int vsize = 0;
	while (csize) {
		vsize = csize;
		if (csize>MAX_TRANSFER)
			if (csize-MAX_TRANSFER < rsize)
				job.count = csize - rsize;
			else
				job.count = MAX_TRANSFER;
		else
			job.count = csize;
		csize -= job.count;
		if (do_spi_transfer(&job)<0) {
			PyErr_SetFromErrno(PyExc_IOError);
			goto r_buf;
		}
	}
	if (rsize > vsize)
		rsize = vsize;
	r = Py_BuildValue("s#", buf+vsize-rsize, rsize);

r_buf:
	PyBuffer_Release(buffer);
r_view:
	Py_DECREF(mview);
	return r;
}

static PyObject * volatile inject_cmd = NULL;

static PyObject *inject_transfer(PyObject *self, PyObject *args, PyObject *kw)
{
	static char *arg_names[] = {"cmd", NULL};
	PyObject *cmd;
	if (!PyArg_ParseTupleAndKeywords(args, kw, 
					 "O", arg_names,
					 &cmd))
		return NULL;
	if (inject_cmd) {
		PyErr_SetString(PyExc_ValueError, "injection busy");
		return NULL;
	}
	Py_INCREF(cmd);
	inject_cmd = cmd;
	Py_RETURN_NONE;
}

static PyObject *stream_transfer(PyObject *self, PyObject *args, PyObject *kw)
{
	PyObject *r = NULL;
	static char *arg_names[] = {"poll", "rsize", "flags", "zero", "fd", NULL};
	int rsize=MAX_TRANSFER, fd=-1, flags=0;
	__u32 zero = 0;
	unsigned int pcmd;
	if (!PyArg_ParseTupleAndKeywords(args, kw, 
					 "i|iiii", arg_names,
					 &pcmd, &rsize, &flags, &zero, &fd))
		return NULL;
	if (set_job_fd(&job, fd))
		return NULL;
	if (rsize>MAX_TRANSFER) {
		PyErr_SetString(PyExc_ValueError, "resp request to large");
		return NULL;
	}
	PyObject *mview;
	Py_buffer *buffer;
	PyObject *cmd = inject_cmd;
	inject_cmd = NULL;
	if (cmd) {
		mview = PyMemoryView_FromObject(cmd);
		if (!mview) 
			goto r_cmd;
		buffer = PyMemoryView_GET_BUFFER(mview);
		if (!buffer)
			goto r_view;
		if (buffer->len > rsize) {
			PyErr_SetString(PyExc_ValueError, "inject cmd too long");
			goto r_buf;
		}
		job.command = buffer->buf;
		job.count = buffer->len;
	}
	else {
		job.count = 0;
	}
	job.idle = pcmd;
	job.flags = flags;
	job.buf_count = rsize;
	job.buf_ptr = NULL;
	if (do_spi_transfer(&job)<0) {
		PyErr_SetFromErrno(PyExc_IOError);
		goto r_buf;
	}
	static __u32 zbuf[MAX_TRANSFER*3/2];
	if (flags & STREAM_DROP_ZEROS) {
		int nz = 0;
		if (flags & FRAME_LONG) {
			__u32 *s = (__u32 *)buf;
			__u32 *z = (__u32 *)zbuf;
			for (int i=0; i<rsize; i+=4)
				if (s[i]!=zero) {
					*z++ = s[i];
					nz+=4;
				}
		}
		else if (flags & FRAME_WORD) {
			__u16 *s = (__u16 *)buf;
			__u16 *z = (__u16 *)zbuf;
			for (int i=0; i<rsize; i+=2)
				if (s[i]!=zero) {
					*z++ = s[i];
					nz+=2;
				}
		}
		else {
			__u8 *s = (__u8 *)buf;
			__u8 *z = (__u8 *)zbuf;
			for (int i=0; i<rsize; i++)
				if (s[i]!=zero) {
					*z++ = s[i];
					nz++;
				}
		}
		r = Py_BuildValue("s#", zbuf, nz);
	}
	else if (flags & STREAM_COMPRESS) {
		int nz = 0;
		int nn = 0;
		if (flags & FRAME_LONG) {
			__u32 *s = (__u32 *)buf;
			__u32 *z = (__u32 *)zbuf;
			for (int i=0; i<rsize; i+=4)
				if (s[i]==zero)
					nn++;
				else if (nn) {
					*z++ = zero;
					*z++ = nn;
					nn = 0;
					*z++ = s[i];
					nz+=12;
				}
				else {
					*z++ = s[i];
					nz+=4;	
				}
		}
		else if (flags & FRAME_WORD) {
			__u16 *s = (__u16 *)buf;
			__u16 *z = (__u16 *)zbuf;
			for (int i=0; i<rsize; i+=2)
				if (s[i]==zero)
					nn++;
				else if (nn) {
					*z++ = zero;
					*z++ = nn;
					nn = 0;
					*z++ = s[i];
					nz+=6;
				}
				else {
					*z++ = s[i];
					nz+=2;
				}
		}
		else {
			__u8 *s = (__u8 *)buf;
			__u8 *z = (__u8 *)zbuf;
			for (int i=0; i<rsize; i++)
				if (s[i]==zero) 
					nn++;
				else if (nn) {
					*z++ = zero;
					if (nn>0xff)
						*z++ = 0xff;
					else
						*z++ = nn;
					nn = 0;
					*z++ = s[i];
					nz+=3;
				}
				else {
					*z++ = s[i];
					nz++;
				}
		}
		r = Py_BuildValue("s#", zbuf, nz);
	}
	else 
		r = Py_BuildValue("s#", buf, rsize);
	
r_buf:
	if (cmd)
		PyBuffer_Release(buffer);
r_view:
	if (cmd)
		Py_DECREF(mview);
r_cmd:
	if (cmd)
		Py_DECREF(cmd);
	return r;
}

struct packetdef {
	__u32 header;
	__u32 mask;
	int size;
	int size_index;
	int size_units;
	__u32 size_mask;
	__u32 bits_mask;
};
static struct packetdef packets[4];

static int set_packets_from_tuple(PyObject *Packets)
{
	PyObject *Packet[4] = {NULL,NULL,NULL,NULL};
	if (PyTuple_Check(Packets)) {
		if (!PyArg_ParseTuple(Packets, "O|OOO", Packet+0, Packet+1, Packet+2, Packet+3))
			return 0;
	}
	else
		Packet[0] = Packets;

	static char *parg_names[] = {
		"header", "mask", "size", 
		"size_index", "size_units", 
		"size_mask", "bits_mask",
		NULL};

	for (int i=0; i<4; i++)  {
		struct packetdef *p = packets+i;
		p->mask = 0;
		p->size = 0;
		p->size_index = 2;
		p->size_units = 2;
		p->size_mask = 0;
		p->bits_mask = 0;
		if (Packet[i]) {
			static PyObject *Empty = NULL;
			if (!Empty) {
				Empty = PyTuple_New(0);
				if (!Empty)
					return 0;
			}
			p->mask = 0xffff;
			if (!PyArg_ParseTupleAndKeywords(Empty, Packet[i], "i|iiiiii", parg_names,
							 &p->header, &p->mask, &p->size,
							 &p->size_index, &p->size_units, 
							 &p->size_mask, &p->bits_mask ))
				return 0;
		}
	}

	return 1;
}

static PyObject *parse_packets(PyObject *self, PyObject *args, PyObject *kw)
{
	static char *arg_names[] = {"buf", "flags", "packets", NULL};
	unsigned int flags = 0;
	__u32 *buf;
	int bsize;
	PyObject *Packets = NULL;
	if (!PyArg_ParseTupleAndKeywords(args, kw, 
					 "s#|iO", arg_names,
					 &buf, &bsize, &flags, &Packets))
		return NULL;
	if (Packets && !set_packets_from_tuple(Packets))
		return NULL;

	for (int i=0; i<4; i++) {
		struct packetdef *p = packets+i;
		if (p->mask && (*buf & p->mask)==p->header) {
			int size = p->size;
			if (bsize >= size && p->size_mask)
				size += (*(__u32*)((__u8*)buf+p->size_index) & p->size_mask)*p->size_units;
			else if (bsize >= size && p->bits_mask) {
				__u32 bits = *(__u32*)((__u8*)buf+p->size_index) & p->bits_mask;
				while (bits) {
					size += p->size_units;
					bits &= bits-1;
				}
			}
			if (bsize >= size)
				return Py_BuildValue("is#s#", i, buf, size, ((__u8*)buf) + size, bsize - size);
			else
				return Py_BuildValue("is#s#", -2, "", 0, buf, bsize);
		}
	}
	int ii = 1;
	if (flags & FRAME_LONG)
		ii = 4;
	else if (flags & FRAME_WORD)
		ii = 2;
	for (int n=ii; n<=bsize-ii; n+= ii)
		for (int i=0; i<4; i++) {
			struct packetdef *p = packets+i;
			if (p->mask && (*(__u32*)((__u8*)buf+n) & p->mask)==p->header)
				return Py_BuildValue("is#s#", -1, buf, n, (__u8*)buf+n, bsize-n);
		}
	return Py_BuildValue("is#s#", -1, buf, bsize, "", 0);
}

static PyMethodDef spidevMethods[] = {
    {"set_mode",  (PyCFunction)set_mode, METH_VARARGS | METH_KEYWORDS, "Set clock mode cpol and cpha."},
    {"set_speed",  (PyCFunction)set_speed, METH_VARARGS | METH_KEYWORDS, "Set max speed in Hz."},
    {"set_lsb_first",  (PyCFunction)set_lsb_first, METH_VARARGS | METH_KEYWORDS, "Set LSB first mode."},
    {"sync_transfer", (PyCFunction)sync_transfer, METH_VARARGS | METH_KEYWORDS, "Synchronous write/read"}, 
    {"inject_transfer", (PyCFunction)inject_transfer, METH_VARARGS | METH_KEYWORDS, "Inject write into Stream"}, 
    {"stream_transfer", (PyCFunction)stream_transfer, METH_VARARGS | METH_KEYWORDS, "Streaming read"}, 
    {"parse_packets", (PyCFunction)parse_packets, METH_VARARGS | METH_KEYWORDS, "Parse pakets from stream"}, 

    {NULL, NULL, 0, NULL}        /* Sentinel */
};

PyMODINIT_FUNC
initspidev(void)
{
	PyObject *m = Py_InitModule("spidev", spidevMethods);
	PyModule_AddIntMacro(m, FRAME_BYTE);
	PyModule_AddIntMacro(m, FRAME_WORD);
	PyModule_AddIntMacro(m, FRAME_LONG);
	PyModule_AddIntMacro(m, STREAM_COMPRESS); 
	PyModule_AddIntMacro(m, STREAM_DROP_ZEROS); 
	PyModule_AddIntMacro(m, INVERT_BITS_OUT); 
}
